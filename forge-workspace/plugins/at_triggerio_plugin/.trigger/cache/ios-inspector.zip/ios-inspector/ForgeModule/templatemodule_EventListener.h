#import <ForgeCore/ForgeCore.h>

@interface templatemodule_EventListener : ForgeEventListener

// You should not need to edit this file.

@end
