//
//  alert_EventListener.h
//  ForgeInspector
//
//  Created by Connor Dunn on 09/10/2012.
//  Copyright (c) 2012 Trigger Corp. All rights reserved.
//

#import <ForgeCore/ForgeCore.h>

@interface alert_EventListener : ForgeEventListener

@end
